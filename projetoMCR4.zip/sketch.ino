#include <WiFi.h>
#include <PubSubClient.h> 
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ezButton.h>
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
const char* ssid = "Galaxy";
const char* password = "12345678";
const char* mqtt_server = "test.mosquitto.org";
String stMac;
char mac[50];
char clientId[50];
int estado;
#define led0 2
#define led1 4
ezButton button0(19); // botoes definidos preto
ezButton button1(12); //cinza
ezButton button2(13); // vermelho
ezButton button3(18);  // branco = enter
char sabor[20]; // 4queijos, 4carnes, frango
char tamanho[20]; // pequena, media, grande,
char borda[20]; // cheddar, catupiry, sem-borda(borda ficticia)
char tipo[20]; //saboroso, zero, normal
int posicao;
int apertado; 
int controle;
int potenciometro;
WiFiClient espClient;
PubSubClient client(espClient);


void setup() {
  pinMode(led0, OUTPUT);
  pinMode(led1, OUTPUT);
  pinMode(potenciometro, INPUT);
  int apertado = 0;
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  Serial.begin(9600);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
  button0.setDebounceTime(900);
  button1.setDebounceTime(900);
  button2.setDebounceTime(900);
  button3.setDebounceTime(900);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 30);
  potenciometro = 36;
  controle = 0;
  display.println("pizza-hut");
  display.display();
  estado = 11;

}

void reconnect() {

 while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    long r = random(1000);
    sprintf(clientId, "clientId-%d", r);
    if (client.connect(clientId)) {
      Serial.print(clientId);
      Serial.println(" connected");
      client.subscribe("Mcr/Pizza");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void setup_wifi() {

   delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}


void callback(char* topic, byte* message, unsigned int length) {


  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  String stMessage;
  for (int i = 0; i < length; i++) {
    Serial.print((char)message[i]);
    stMessage += (char)message[i];
  }
  Serial.println();
  String strPayload = String((char*)message);


  if (String(topic) == "Mcr/Pizza") {
    if (stMessage == "sos") {
      controle = 901;//aqui está o botao de emergencia
    }
    if (stMessage == "enter") {
      controle = 900;
    }
  }
}

void loop() {
  if (!client.connected()) {
  reconnect();
}
client.loop();
  if (controle == 901) {
    estado = 11;
    apertado = 0;
    display.clearDisplay();

    display.setTextSize(1);
    display.setTextColor(WHITE);
    display.setCursor(20, 0);
    digitalWrite((led0), HIGH);
    digitalWrite((led1), HIGH);
    delay(500);
    digitalWrite((led0), LOW);
    digitalWrite((led1), LOW);
    controle = 0;


  }




  switch (estado) {
    case 11: pizzaria(); break;
    case 0: sAbor(); break;
    case 1: saborselect(); break;
    case 2: tAmanho(); break;
    case 3: tamanhoselect(); break;
    case 4: bOrda(); break;
    case 5: bordaselect(); break;
    case 6: process(); break;
    case 7: processconfirm(); break;
    case 8: esquentando(); break;
    case 9: retirada(); break;

  }

  button0.loop();
  button1.loop();
  button2.loop();
  button3.loop();

}

void pizzaria() {
  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 30);
  display.println("aperte enter para comecar");
  display.display();
  if ((button3.isPressed() || (controle == 900)) && apertado == 0) {
    estado = 0;
    apertado = 0;
  }
}


void sAbor() {
  controle = 0;

  display.clearDisplay();
  //}
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(20, 0);
  display.println("escolha o sabor ");
  display.setCursor(20, 10);
  display.println(" 4queijos(preto)");
  display.setCursor(20, 20);
  display.println(" frango(cinza)");
  display.setCursor(20, 30);
  display.println(" 4carnes(vermelho)");
  display.setCursor(20, 40);
  display.println(" aperte enter");
  display.setCursor(20, 50);
  display.println(" quando escolher");
  display.display();
  estado = 1;
}


void saborselect() {
 

  if (button0.isPressed()) { //selecionado 4queijos
    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(sabor, "4queijos");
  } else {
    digitalWrite(led1, LOW);
  }

  if (button1.isPressed()) { //selecionado frango
    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(sabor, "frango");
  } else {
    digitalWrite(led1, LOW);
  }

  if (button2.isPressed()) { // selecionado 4carnes
    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(sabor, "4carnes");
  } else {
    digitalWrite(led1, LOW);
  }
  if (button3.isPressed() ){

    estado = 2;
  }
}


void tAmanho() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(20, 00);
  display.println("escolha o tamanho ");
  display.setCursor(20, 10);
  display.println(" media(cinza)");
  display.setCursor(20, 20);
  display.println(" grande(vermelho)");
  display.setCursor(20, 30);
  display.println(" pequena(preto)");
  display.setCursor(20, 40);
  display.println(" pressione enter");
  display.setCursor(20, 50);
  display.println(" quando escolher");
  display.display();
  controle = 0;
  estado = 3;
  delay(1000);
}



void tamanhoselect() {
  if (button0.isPressed()) { //tamanho escolhido pequeno

    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(tamanho, "pequena");

  } else {
    digitalWrite(led1, LOW);
  }

  if (button1.isPressed()) { //tamanho escolhido medio

    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(tamanho, "media");
  }

  else {
    digitalWrite(led1, LOW);
  }

  if (button2.isPressed()) { //tamanho escolhido grande

    digitalWrite((led1), HIGH);
    delay(1000);
    strcpy(tamanho, "grande");
  } else {
    digitalWrite(led1, LOW);
  }


  if (button3.isPressed())
  {
    estado = 4;
  }
}


void bOrda() {


  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(20, 00);
  display.println("escolha a borda ");
  display.setCursor(20, 10);
  display.println(" cheddar(preto)");
  display.setCursor(20, 20);
  display.println(" catupiry(cinza)");
  display.setCursor(20, 30);
  display.println(" sem borda(vermelho)");
  display.setCursor(20, 40);
  display.println(" pressione enter");
  display.setCursor(20, 50);
  display.println(" quando escolher");
  display.display();
  controle = 0;
  estado = 5;
}

void bordaselect() {
  if (button0.isPressed()) {
    digitalWrite((led1), HIGH);
    delay(1000);
    
    strcpy(borda, "cheddar");

  } else {
    digitalWrite(led1, LOW);
  }
  if (button1.isPressed()) { 
    digitalWrite((led1), HIGH);
    delay(1000);
    
    strcpy(borda, "catupiry");

  } else {
    digitalWrite(led1, LOW);
  }
  if (button2.isPressed()) { 
    digitalWrite((led1), HIGH);
    delay(1000);
    
    strcpy(borda, "sem borda");

  } else {
    digitalWrite(led1, LOW);
  }

  if (button3.isPressed() )
  {
    estado = 6;
  }
}

void process() { // processamneto do pedido
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(00, 0);
  display.println("processando!! ");
  display.setCursor(20, 20);
  display.println(" ESPERE ");
  display.display();
  delay(1000);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(00, 0);
  display.println("processado! ");
  display.setCursor(20, 10);
  display.println(" confira na proxima");
  display.setCursor(20, 20);
  display.println(" etapa !");
  display.display();
  delay(1000);
  estado = 7;
}

void processconfirm() { 
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(00, 00);
  display.print("tamanho = ");
  display.setCursor(87, 00);
  display.print(tamanho);
  display.setCursor(0, 15);
  display.print(" sabor = ");
  display.setCursor(60, 15);
  display.println(sabor);
  display.setCursor(0, 30);
  display.print(" borda = ");
  display.setCursor(75, 30);
  display.print(borda);
  display.setCursor(0, 40);
  display.print("se estiver certo(enter) e errado(vermelho) ");
  display.display();
  controle = 0;

  if (button3.isPressed()) { 
    digitalWrite(led0, HIGH);
    digitalWrite(led1, HIGH);
    apertado = 0;
    delay(2000);
    estado = 8;
  } if (button2.isPressed()) { 
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(WHITE);
    display.setCursor(00, 0);
    display.println("desculpas ");
    display.setCursor(00, 15);
    display.print("tente denovo");
    display.display();
    delay(1000);
    estado = 0;
    apertado = 0;
    controle = 0;

  }
}

void esquentando() {
 
  controle = 0;
  apertado = 0;
  display.clearDisplay();
  digitalWrite(led0, LOW);
  digitalWrite(led1, LOW);
  posicao = analogRead(potenciometro);
  posicao = ((posicao * 100) / 4095);
  display.setCursor(00, 40);
  display.println("esquentando :");
  display.setCursor(80, 40);
  display.println(posicao);
  display.setCursor(0, 50);
  display.print(" pressione o preto quando esquentar");
  display.display();
  delay(1000);
 // if(button0.isPressed()){
  if(posicao >= 100){
    estado = 9;
  }}


void retirada() { 
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(00, 0);
  display.println("cuidado esta quente ");
  display.setCursor(00, 10);
  display.println("pegue sua pizza");
  display.display();
  delay(2000);
  estado = 11;
  apertado = 0;


}